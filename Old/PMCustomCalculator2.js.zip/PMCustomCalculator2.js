var CUSTOMCALCULATOR = {
    apiVersion: 1,
    calculate: function (auditResult, calculatorService) {
        var scoredResult = calculatorService.calculateStandardScore(auditResult);
        
        var newOverallScore = auditResult.score.pointsEarned / auditResult.score.questionCount;

		var text = "This is the PM Custom Calculator, a fixed score has been set.";
        if (scoredResult.notes) {
            scoredResult.notes.text = text;
        } else {
            scoredResult.notes = {
                text: text
            };
        }
        
        scoredResult.score.percentage = 1.0;
        
        return scoredResult;
    }
};
